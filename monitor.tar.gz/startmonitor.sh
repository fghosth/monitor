#!/bin/bash
nohup /data/monitor/monitor_linux rs >> /data/monitor/monitor.log 2>&1 &
